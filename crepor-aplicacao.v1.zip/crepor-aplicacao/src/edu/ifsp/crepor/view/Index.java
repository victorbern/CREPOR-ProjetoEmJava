package edu.ifsp.crepor.view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.DropMode;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

//import edu.ifsp.crepor.diversos.Materiais;
//import edu.ifsp.crepor.diversos.Sobre;


public class Index {
	private JFrame frame;
	private JTextField txtPesquisar;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Index window = new Index();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public Index(){
		initialize();
	}
	
	public void initialize(){
		frame = new JFrame();
		frame.setBounds(200, 200, 900, 831);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panelTopo = new JPanel();
		panelTopo.setBounds(0, 0, 884, 38);
		panelTopo.setBackground(Color.LIGHT_GRAY);
		frame.getContentPane().add(panelTopo);
		
		JLabel lblLogo = new JLabel("<html><meta charset='utf-8'>C.R.E.P.O.R.</html>");
		lblLogo.setBackground(Color.LIGHT_GRAY);
		lblLogo.setBounds(10, 0, 125, 38);
		panelTopo.setLayout(null);
		lblLogo.setFont(new Font("Bodoni MT", Font.BOLD, 20));
		panelTopo.add(lblLogo);
		
		txtPesquisar = new JTextField();
		txtPesquisar.setDropMode(DropMode.INSERT);
		txtPesquisar.setBounds(547, 14, 206, 15);
		panelTopo.add(txtPesquisar);
		txtPesquisar.setColumns(10);
		
		JButton botaoBusca = new JButton("Search");
		botaoBusca.setFont(new Font("Arial", Font.BOLD, 12));
		botaoBusca.setBounds(756, 14, 89, 15);
		panelTopo.add(botaoBusca);
		
		JMenuItem botaoPontos = new JMenuItem("Pontos");
		botaoPontos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				PontosDeColeta tela2 = new PontosDeColeta();
				tela2.IniciaTela();
				frame.setVisible(false);
			}
		});
		botaoPontos.setFont(new Font("Calisto MT", Font.PLAIN, 20));
		botaoPontos.setHorizontalAlignment(SwingConstants.CENTER);
		botaoPontos.setBackground(Color.LIGHT_GRAY);
		botaoPontos.setBounds(139, 0, 112, 38);
		panelTopo.add(botaoPontos);
		
		JMenuItem botaoMateriais = new JMenuItem("Materiais");
		botaoMateriais.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
//				Materiais materiais = new Materiais();
//				materiais.IniciaTela();
//				frame.setVisible(false);
			}
		});
		botaoMateriais.setHorizontalAlignment(SwingConstants.LEFT);
		botaoMateriais.setFont(new Font("Calisto MT", Font.PLAIN, 20));
		botaoMateriais.setBackground(Color.LIGHT_GRAY);
		botaoMateriais.setBounds(261, 0, 112, 38);
		panelTopo.add(botaoMateriais);
		
		JMenuItem botaoSobre = new JMenuItem("Sobre");
		botaoSobre.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
//				Sobre sobre = new Sobre();
//				sobre.IniciaTela();
//				frame.setVisible(false);
			}
		});
		botaoSobre.setHorizontalAlignment(SwingConstants.CENTER);
		botaoSobre.setFont(new Font("Calisto MT", Font.PLAIN, 20));
		botaoSobre.setBackground(Color.LIGHT_GRAY);
		botaoSobre.setBounds(389, 0, 112, 38);
		panelTopo.add(botaoSobre);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 761, 884, 38);
		frame.getContentPane().add(panel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setToolTipText("");
		panel_1.setBounds(10, 67, 864, 471);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("      C.R.E.P.O.R.");
		lblNewLabel.setBounds(337, 11, 189, 38);
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setFont(new Font("Calisto MT", Font.PLAIN, 20));
		lblNewLabel.setIcon(new ImageIcon("F:\\Instaladores\\Instalados\\Eclipse\\EclipseWorkspace\\InterfaceGrafica\\img\\img.png"));
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("<html><meta charset='utf-8'>Coleta e Reutiliza��o Ecol�gica de Pilhas, �leo de Rem�dios</html>");
		lblNewLabel_1.setBounds(33, 43, 810, 38);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Calisto MT", Font.PLAIN, 18));
		panel_1.add(lblNewLabel_1);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(54, 84, 768, 376);
		panel_1.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblNossoProjeto = new JLabel("<html><meta charset='utf-8'><font size=5><p align='justify' font-si>Nosso projeto \u00E9 o C.R.E.P.O.R. (Coleta e Reutiliza\u00E7\u00E3o Ecol\u00F3gica de Pilhas, \u00D3leo e Rem\u00E9dios), o problema que percebemos para a cria\u00E7\u00E3o desse projeto \u00E9 a falta de conhecimento das pessoas em rela\u00E7\u00E3o ao descarte de pilhas, \u00F3leo e rem\u00E9dios e suas embalagens, as vezes at\u00E9 sabem que esses res\u00EDduos precisam ser descartados de uma maneira correta mas n\u00E3o sabem onde se localiza os pontos de coleta nem ao menos tem como se comunicar com esses lugares.  Pensamos em criar um site e que contenha endere\u00E7os e contatos de pontos de coleta, onde todas as pessoas tenham acesso, e possam filtrar o endere\u00E7o mais perto de sua casa para fazer o descarte, al\u00E9m dos pontos de coleta colocaremos informa\u00E7\u00F5es sobre os res\u00EDduos, como o que eles causam ao meio ambiente, o que acontece com eles depois de passar pelos pontos de coleta, enfim, o que eles acabam se tornando no final de todo um processo e explicar esse processo tamb\u00E9m.</p></font></html>");
		lblNossoProjeto.setBounds(76, 11, 613, 354);
		panel_3.add(lblNossoProjeto);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(260, 559, 364, 171);
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JButton btnConhecaOsCriadores = new JButton("<html><meta charset='utf-8'>Conhe\u00E7a os criadores</html>");
		btnConhecaOsCriadores.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
//				Sobre sobre = new Sobre();
//				sobre.IniciaTela();
//				frame.setVisible(false);
			}
		});
		btnConhecaOsCriadores.setBackground(Color.WHITE);
		btnConhecaOsCriadores.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnConhecaOsCriadores.setBounds(10, 11, 344, 41);
		panel_2.add(btnConhecaOsCriadores);
		
		JButton btnConhecaOsPontos = new JButton("<html><meta charset='utf-8'>Conhe\u00E7a os pontos de coleta</html>");
		btnConhecaOsPontos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
//				PontosDeColeta tela2 = new PontosDeColeta();
//				tela2.IniciaTela();
//				frame.setVisible(false);
			}
		});
		btnConhecaOsPontos.setBackground(Color.WHITE);
		btnConhecaOsPontos.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnConhecaOsPontos.setBounds(10, 63, 344, 41);
		panel_2.add(btnConhecaOsPontos);
		
		JButton btnDescubraSobreMateriais = new JButton("<html><meta charset='utf-8'>Descubra sobre os materiais</html>");
		btnDescubraSobreMateriais.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
//				Materiais materiais = new Materiais();
//				materiais.IniciaTela();
//				frame.setVisible(false);
			}
		});
		btnDescubraSobreMateriais.setBackground(Color.WHITE);
		btnDescubraSobreMateriais.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnDescubraSobreMateriais.setBounds(10, 115, 344, 41);
		panel_2.add(btnDescubraSobreMateriais);
	}

}
